﻿namespace GameTownsApp
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBegin = new System.Windows.Forms.Button();
            this.rulesOfTheGame = new System.Windows.Forms.Button();
            this.richTextBox = new System.Windows.Forms.RichTextBox();
            this.btnUserTown = new System.Windows.Forms.TextBox();
            this.btnUserTurn = new System.Windows.Forms.Button();
            this.btnNextChar = new System.Windows.Forms.Button();
            this.btnUserHelp = new System.Windows.Forms.Button();
            this.gameScore = new System.Windows.Forms.TextBox();
            this.robotWinLabel1 = new System.Windows.Forms.Label();
            this.robotWinCount = new System.Windows.Forms.Label();
            this.robotWinLabel2 = new System.Windows.Forms.Label();
            this.robotWinScope = new System.Windows.Forms.Label();
            this.userWinLabel1 = new System.Windows.Forms.Label();
            this.userWinCount = new System.Windows.Forms.Label();
            this.userWinLabel2 = new System.Windows.Forms.Label();
            this.userWinScope = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnEnd = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBegin
            // 
            this.btnBegin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnBegin.Location = new System.Drawing.Point(183, 12);
            this.btnBegin.Name = "btnBegin";
            this.btnBegin.Size = new System.Drawing.Size(75, 26);
            this.btnBegin.TabIndex = 0;
            this.btnBegin.Text = "Начать игру";
            this.btnBegin.UseVisualStyleBackColor = true;
            this.btnBegin.Click += new System.EventHandler(this.btnBegin_Click);
            // 
            // rulesOfTheGame
            // 
            this.rulesOfTheGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.rulesOfTheGame.Location = new System.Drawing.Point(264, 12);
            this.rulesOfTheGame.Name = "rulesOfTheGame";
            this.rulesOfTheGame.Size = new System.Drawing.Size(131, 26);
            this.rulesOfTheGame.TabIndex = 1;
            this.rulesOfTheGame.Text = "Правила игры";
            this.rulesOfTheGame.UseVisualStyleBackColor = true;
            this.rulesOfTheGame.Click += new System.EventHandler(this.rulesOfTheGame_Click);
            // 
            // richTextBox
            // 
            this.richTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox.Location = new System.Drawing.Point(183, 41);
            this.richTextBox.Name = "richTextBox";
            this.richTextBox.ReadOnly = true;
            this.richTextBox.Size = new System.Drawing.Size(469, 426);
            this.richTextBox.TabIndex = 4;
            this.richTextBox.Text = "";
            // 
            // btnUserTown
            // 
            this.btnUserTown.Enabled = false;
            this.btnUserTown.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnUserTown.Location = new System.Drawing.Point(183, 473);
            this.btnUserTown.Name = "btnUserTown";
            this.btnUserTown.Size = new System.Drawing.Size(180, 26);
            this.btnUserTown.TabIndex = 5;
            this.btnUserTown.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.btnUserTown_KeyPress);
            // 
            // btnUserTurn
            // 
            this.btnUserTurn.Enabled = false;
            this.btnUserTurn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnUserTurn.Location = new System.Drawing.Point(369, 473);
            this.btnUserTurn.Name = "btnUserTurn";
            this.btnUserTurn.Size = new System.Drawing.Size(87, 26);
            this.btnUserTurn.TabIndex = 6;
            this.btnUserTurn.Text = "Ввести";
            this.btnUserTurn.UseVisualStyleBackColor = true;
            this.btnUserTurn.Click += new System.EventHandler(this.btnUserTurn_Click);
            // 
            // btnNextChar
            // 
            this.btnNextChar.Enabled = false;
            this.btnNextChar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnNextChar.Location = new System.Drawing.Point(462, 473);
            this.btnNextChar.Name = "btnNextChar";
            this.btnNextChar.Size = new System.Drawing.Size(193, 26);
            this.btnNextChar.TabIndex = 9;
            this.btnNextChar.Text = "На какую букву ходить";
            this.btnNextChar.UseVisualStyleBackColor = true;
            this.btnNextChar.Click += new System.EventHandler(this.btnNextChar_Click);
            // 
            // btnUserHelp
            // 
            this.btnUserHelp.Enabled = false;
            this.btnUserHelp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnUserHelp.Location = new System.Drawing.Point(661, 473);
            this.btnUserHelp.Name = "btnUserHelp";
            this.btnUserHelp.Size = new System.Drawing.Size(160, 26);
            this.btnUserHelp.TabIndex = 10;
            this.btnUserHelp.Text = "Подсказка";
            this.btnUserHelp.UseVisualStyleBackColor = true;
            this.btnUserHelp.Click += new System.EventHandler(this.btnUserHelp_Click);
            // 
            // gameScore
            // 
            this.gameScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gameScore.Location = new System.Drawing.Point(498, 12);
            this.gameScore.Name = "gameScore";
            this.gameScore.Size = new System.Drawing.Size(58, 26);
            this.gameScore.TabIndex = 11;
            this.gameScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // robotWinLabel1
            // 
            this.robotWinLabel1.AutoSize = true;
            this.robotWinLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.robotWinLabel1.Location = new System.Drawing.Point(25, 9);
            this.robotWinLabel1.Name = "robotWinLabel1";
            this.robotWinLabel1.Size = new System.Drawing.Size(63, 20);
            this.robotWinLabel1.TabIndex = 13;
            this.robotWinLabel1.Text = "Побед:";
            // 
            // robotWinCount
            // 
            this.robotWinCount.AutoSize = true;
            this.robotWinCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.robotWinCount.Location = new System.Drawing.Point(89, 9);
            this.robotWinCount.Name = "robotWinCount";
            this.robotWinCount.Size = new System.Drawing.Size(18, 20);
            this.robotWinCount.TabIndex = 14;
            this.robotWinCount.Text = "0";
            // 
            // robotWinLabel2
            // 
            this.robotWinLabel2.AutoSize = true;
            this.robotWinLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.robotWinLabel2.Location = new System.Drawing.Point(25, 41);
            this.robotWinLabel2.Name = "robotWinLabel2";
            this.robotWinLabel2.Size = new System.Drawing.Size(51, 20);
            this.robotWinLabel2.TabIndex = 15;
            this.robotWinLabel2.Text = "Счет:";
            // 
            // robotWinScope
            // 
            this.robotWinScope.AutoSize = true;
            this.robotWinScope.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.robotWinScope.Location = new System.Drawing.Point(89, 41);
            this.robotWinScope.Name = "robotWinScope";
            this.robotWinScope.Size = new System.Drawing.Size(18, 20);
            this.robotWinScope.TabIndex = 16;
            this.robotWinScope.Text = "0";
            // 
            // userWinLabel1
            // 
            this.userWinLabel1.AutoSize = true;
            this.userWinLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.userWinLabel1.Location = new System.Drawing.Point(674, 9);
            this.userWinLabel1.Name = "userWinLabel1";
            this.userWinLabel1.Size = new System.Drawing.Size(63, 20);
            this.userWinLabel1.TabIndex = 17;
            this.userWinLabel1.Text = "Побед:";
            // 
            // userWinCount
            // 
            this.userWinCount.AutoSize = true;
            this.userWinCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.userWinCount.Location = new System.Drawing.Point(745, 10);
            this.userWinCount.Name = "userWinCount";
            this.userWinCount.Size = new System.Drawing.Size(18, 20);
            this.userWinCount.TabIndex = 18;
            this.userWinCount.Text = "0";
            // 
            // userWinLabel2
            // 
            this.userWinLabel2.AutoSize = true;
            this.userWinLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.userWinLabel2.Location = new System.Drawing.Point(674, 41);
            this.userWinLabel2.Name = "userWinLabel2";
            this.userWinLabel2.Size = new System.Drawing.Size(51, 20);
            this.userWinLabel2.TabIndex = 19;
            this.userWinLabel2.Text = "Счет:";
            // 
            // userWinScope
            // 
            this.userWinScope.AutoSize = true;
            this.userWinScope.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.userWinScope.Location = new System.Drawing.Point(745, 41);
            this.userWinScope.Name = "userWinScope";
            this.userWinScope.Size = new System.Drawing.Size(18, 20);
            this.userWinScope.TabIndex = 20;
            this.userWinScope.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(401, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "Счет игры:";
            // 
            // btnEnd
            // 
            this.btnEnd.Enabled = false;
            this.btnEnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnEnd.ForeColor = System.Drawing.Color.Red;
            this.btnEnd.Location = new System.Drawing.Point(569, 12);
            this.btnEnd.Name = "btnEnd";
            this.btnEnd.Size = new System.Drawing.Size(83, 26);
            this.btnEnd.TabIndex = 22;
            this.btnEnd.Text = "Сдаться";
            this.btnEnd.UseVisualStyleBackColor = true;
            this.btnEnd.Click += new System.EventHandler(this.btnEnd_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::GameTownsApp.Properties.Resources.Bender5;
            this.pictureBox2.Location = new System.Drawing.Point(1, 64);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(180, 403);
            this.pictureBox2.TabIndex = 23;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GameTownsApp.Properties.Resources.Fray2;
            this.pictureBox1.Location = new System.Drawing.Point(668, 64);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(153, 403);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 503);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btnEnd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.userWinScope);
            this.Controls.Add(this.userWinLabel2);
            this.Controls.Add(this.userWinCount);
            this.Controls.Add(this.userWinLabel1);
            this.Controls.Add(this.robotWinScope);
            this.Controls.Add(this.robotWinLabel2);
            this.Controls.Add(this.robotWinCount);
            this.Controls.Add(this.robotWinLabel1);
            this.Controls.Add(this.gameScore);
            this.Controls.Add(this.btnUserHelp);
            this.Controls.Add(this.btnNextChar);
            this.Controls.Add(this.btnUserTurn);
            this.Controls.Add(this.btnUserTown);
            this.Controls.Add(this.richTextBox);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.rulesOfTheGame);
            this.Controls.Add(this.btnBegin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Игра \"Города\"";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBegin;
        private System.Windows.Forms.Button rulesOfTheGame;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RichTextBox richTextBox;
        private System.Windows.Forms.TextBox btnUserTown;
        private System.Windows.Forms.Button btnUserTurn;
        private System.Windows.Forms.Button btnNextChar;
        private System.Windows.Forms.Button btnUserHelp;
        private System.Windows.Forms.TextBox gameScore;
        private System.Windows.Forms.Label robotWinLabel1;
        private System.Windows.Forms.Label robotWinCount;
        private System.Windows.Forms.Label robotWinLabel2;
        private System.Windows.Forms.Label robotWinScope;
        private System.Windows.Forms.Label userWinLabel1;
        private System.Windows.Forms.Label userWinCount;
        private System.Windows.Forms.Label userWinLabel2;
        private System.Windows.Forms.Label userWinScope;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnEnd;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

