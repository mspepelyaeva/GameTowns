﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using HorizontalAlignment = System.Windows.Forms.HorizontalAlignment;

namespace GameTownsApp
{
    public partial class MainForm : Form
    {
        private int userHelpCount = 5;       // Количество подсказок игрока
        private int robotGameCount = 0;      // Количество побед компьютера
        private int userGameCount = 0;       // Количество побед игрока
        private int robotTotalScope = 0;     // Счет побед компьютера
        private int userTotalScope = 0;      // Счет побед игрока
        private int robotScope = 0;          // Счет компьютера
        private int userScope = 0;           // Счет игрока
        private bool isStartGame = false;    // Статус игры
        private bool isUserTurn = true;      // Первый ход игрока
        private char nextChar = ' ';         // Начальная буква города
        private List<Turn> turns;            // Названные города
        private List<string> knowledgeBase;  // База знаний (все известные города)

        public MainForm()
        {
            InitializeComponent();
        }

        // Начало игры
        private void btnBegin_Click(object sender, EventArgs e)
        {
            isStartGame = true;
            isUserTurn = true;

            btnBegin.Enabled = false;
            btnEnd.Enabled = true;
            btnUserTown.Enabled = true;
            btnUserTurn.Enabled = true;

            userHelpCount = 50;
            robotScope = 0;
            userScope = 0;
            nextChar = ' ';
            turns = new List<Turn>();
            richTextBox.Clear();
            rulesOfTheGame_Click(sender, e);
            btnUserHelpUpdate();

            knowledgeBase = new List<string>();
            string[] towns = System.IO.File.ReadAllLines("Towns.txt");
            foreach (string town in towns)
            {
                knowledgeBase.Add(town.Trim());
            }
        }

        // Правила игры
        private void rulesOfTheGame_Click(object sender, EventArgs e)
        {
            string text = "Правила игры: Вы называете город, я говорю город на " +
                "последнюю букву - и так далее. Только учтите - мягкий знак и буква 'ы' " +
                "не считаются. Если вам нужна будет моя помощь, нажмите кнопку " +
                "'дай подсказку'. Ходите.\r\n";
            richTextBox.AppendText(text);
        }

        // Конец игры
        private void endGame(bool userWinner)
        {
            isStartGame = false;
            btnBegin.Enabled = true;
            btnEnd.Enabled = false;
            btnUserTurn.Enabled = false;
            btnUserHelp.Enabled = false;
            btnNextChar.Enabled = false;
            if (userWinner)
            {
                userGameCount++;
                userTotalScope += userScope;
                richTextBox.AppendText("Ты выиграл\r\n");
            }
            else
            {
                robotGameCount++;
                robotTotalScope += robotScope;
                richTextBox.AppendText("Ты проиграл\r\n");
            }
            robotWinCount.Text = robotGameCount.ToString();
            robotWinScope.Text = robotTotalScope.ToString();
            userWinCount.Text = userGameCount.ToString();
            userWinScope.Text = userTotalScope.ToString();
        }

        private void btnEnd_Click(object sender, EventArgs e)
        {
            endGame(false);
        }

        // Ход игрока (Enter)
        private void btnUserTown_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Return)
            {
                btnUserTurn_Click(sender, e);
            }
        }

        // Ход игрока
        private void btnUserTurn_Click(object sender, EventArgs e)
        {
            string town = btnUserTown.Text;
            if (town != null && town.Length != 0)
            {
                if (town.ToUpper().ElementAt(0) != nextChar && nextChar != ' ')
                {
                    richTextBox.AppendText("город на букву '" + nextChar + "'\r\n");
                    return;
                }
                if (registerTown(ref town))
                {
                    userScope++;
                    writeTown(isUserTurn, town);
                    isUserTurn = false;
                    btnUserTown.Text = "";

                    // Ход компьютера
                    btnRobotTurn();
                } else
                {
                    string townRandom = nextTownRandom(true);
                    if (townRandom.Length == 0)
                    {
                        endGame(false);
                    }
                }
            }
        }

        // Подсказка игроку
        private void btnUserHelp_Click(object sender, EventArgs e)
        {
            if (userHelpCount > 0)
            {
                userHelpCount--;
                btnUserHelpUpdate();
                btnUserTown.Text = nextTownRandom(false);
            }
        }

        // Ход компьютера
        private void btnRobotTurn()
        {
            string town = nextTownRandom(false);
            if (town.Length == 0)
            {
                endGame(true);
            }
            else
            {
                if (registerTown(ref town))
                {
                    robotScope++;
                    writeTown(isUserTurn, town);
                    isUserTurn = true;
                    btnUserHelp.Enabled = true;
                    btnNextChar.Enabled = true;
                }
            }
        }

        // Вывод на кнопке "Подсказка" оставшееся количество подсказок
        private void btnUserHelpUpdate()
        {
            if (userHelpCount <= 0)
                btnUserHelp.Visible = false;
            else
                btnUserHelp.Text = "Подсказка (" + userHelpCount + ")";
        }

        // Добавление города в чат
        private void writeTown(bool user, string town)
        {
            Turn turnRobot = new Turn(user, turns.Count, town);
            turns.Add(turnRobot);
            if (user)
            {
                richTextBox.AppendText("Фрай: ");
            }
            else
            {
                richTextBox.AppendText("Бендер: ");
            }
            string text = town + "\r\n";
            int start = richTextBox.Text.Length;
            richTextBox.AppendText(text);
            richTextBox.Select(start, text.Length);
            richTextBox.SelectionFont = new System.Drawing.Font("Tahoma", 14);
            if (user)
            {
                richTextBox.SelectionColor = Color.Blue;
                richTextBox.SelectionAlignment = HorizontalAlignment.Right;
                richTextBox.SelectionBackColor = Color.Aquamarine;
            } else
            {
                richTextBox.SelectionColor = Color.Red;
                richTextBox.SelectionAlignment = HorizontalAlignment.Left;
                richTextBox.SelectionBackColor = Color.Aqua;
            }

            gameScore.Text = robotScope + " : " + userScope;

            richTextBox.ScrollToCaret();
        }

        // На какую букву ходить
        private void btnNextChar_Click(object sender, EventArgs e)
        {
            richTextBox.AppendText("город на букву '" + nextChar + "'\r\n");
        }

        // Регистрация города, с его удалением из базы городов
        private bool registerTown(ref string town)
        {
            // Ранее названные города
            for (int i = 0; i < turns.Count; i++)
            {
                Turn turn = turns[i];
                if (string.Equals(town, turn.getTown(), StringComparison.OrdinalIgnoreCase))
                {
                    if (turn.getUser())
                    {
                        richTextBox.AppendText("город '" + town + "' ты уже называл\r\n");
                    } else
                    {
                        richTextBox.AppendText("город '" + town + "' я уже называл\r\n");
                    }
                    return false;
                }
            }
            // Поиск в базе городов
            int townIndex = -1;
            for (int i = 0; i < knowledgeBase.Count; i++)
            {
                if (string.Equals(town, knowledgeBase[i], StringComparison.OrdinalIgnoreCase))
                {
                    town = knowledgeBase[i];
                    townIndex = i;
                    break;
                }
            }
            if (townIndex == -1)
            {
                richTextBox.AppendText("город '" + town + "' мне не знаком\r\n");
                return false;
            }
            knowledgeBase.RemoveAt(townIndex);
            townNextChar(town);
            return true;
        }

        // Последняя буква в названии города  
        private void townNextChar(string town)
        {
            for (int i = town.Length; i > 0; i--)
            {
                nextChar = town.ToUpper().ElementAt(i - 1);
                if (nextChar != 'Ы' && nextChar != 'Ь')
                {
                    break;
                }
            }
        }

        // Подбор города из базы городов
        private string nextTownRandom(bool flagControlEndGame)
        {
            List<string> version = new List<string>();
            for (int i = 0; i < knowledgeBase.Count; i++)
            {
                string town = knowledgeBase[i];
                if (town.ElementAt(0) == nextChar)
                {
                    version.Add(town);
                }
            }
            if (version.Count == 0)
            {
                isStartGame = false;
                btnUserHelp.Enabled = false;
                richTextBox.AppendText("Закончились варианты городов на букву '" + nextChar + "'\r\n");
                return "";
            }
            //инициализация ДСЧ
            Random rnd = new Random((int)DateTime.Now.Ticks);
            int index = rnd.Next(0, version.Count);
            return version[index];
        }
    }
}
