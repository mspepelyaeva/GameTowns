﻿namespace GameTownsApp
{
    class Turn
    {
        private bool user;
        private int step;
        private string town;

        public Turn(bool user, int step, string town)
        {
            this.user = user;
            this.step = step;
            this.town = town;
        }

        public bool getUser()
        {
            return user;
        }

        public string getTown()
        {
            return town;
        }
    }
}
